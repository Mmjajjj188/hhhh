<?php
include 'index.php';
var_dump(checkGmail('manumontteeee45@gmail.com'));